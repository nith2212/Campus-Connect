package com.example.loginmodule.service;

import com.example.loginmodule.dto.AuthResponse;
import com.example.loginmodule.dto.LoginRequest;
import com.example.loginmodule.dto.RegisterRequest;
import com.example.loginmodule.entity.User;
import com.example.loginmodule.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authManager;

    public AuthResponse register(RegisterRequest request) {
        // Logging removed as it was for debugging;
        // if you want to keep them, that's fine.

        User user = User.builder()
                .name(request.getName()) // Correctly setting the 'name'
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .build();
        userRepository.save(user);
        return AuthResponse.builder()
                .token(jwtService.generateToken(user.getEmail(), user.getRole().name(), user.getId().toString())) // Pass role & ID
                .build();
    }

    public AuthResponse login(LoginRequest request) {
        authManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );
        User user = userRepository.findByEmail(request.getEmail()).orElseThrow(
                () -> new RuntimeException("User not found")
        );
        return AuthResponse.builder()
                .token(jwtService.generateToken(user.getEmail(), user.getRole().name(), user.getId().toString())) // Pass role & ID
                .build();
    }
}