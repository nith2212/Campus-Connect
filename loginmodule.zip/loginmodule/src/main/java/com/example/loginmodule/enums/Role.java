package com.example.loginmodule.enums;

public enum Role {
    STUDENT,
    FACULTY,
    ADMIN
}