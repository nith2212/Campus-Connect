package com.example.adminmodule.enums;

public enum Role {
    STUDENT,
    FACULTY,
    ADMIN
}