package com.example.adminmodule.service;

import com.example.adminmodule.dto.UserDTO;
import com.example.adminmodule.entity.User; // Corrected: Now importing User from adminmodule's entity package
import com.example.adminmodule.enums.Role; // Corrected: Now importing Role from adminmodule's enums package
import com.example.adminmodule.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final UserRepository userRepository;

    public List<UserDTO> getAllUsers() {
        return userRepository.findAll().stream()
                .map(user -> UserDTO.builder()
                        .id(user.getId())
                        .name(user.getName())
                        .email(user.getEmail())
                        .role(user.getRole().name()) // Assuming getRole() returns the enum
                        .build())
                .collect(Collectors.toList());
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public void updateUserRole(Long userId, String newRole) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setRole(Role.valueOf(newRole.toUpperCase()));
        userRepository.save(user);
    }
}