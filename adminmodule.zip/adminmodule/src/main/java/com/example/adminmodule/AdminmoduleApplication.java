package com.example.adminmodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class AdminmoduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminmoduleApplication.class, args);
	}

}
