package com.example.adminmodule.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.security.Key;
import java.util.List;
import lombok.extern.slf4j.Slf4j; // Added for logging

@Component
@Slf4j // Added for logging
public class JwtAuthFilter extends OncePerRequestFilter {

    private final String jwtSecret = "d8VHwJ39b7tqFNnUyERntTHf0kLBZ8Yz7aVrrf98LXU=";

    private Key getSignKey() {
        byte[] keyBytes = Decoders.BASE64.decode(jwtSecret);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String authHeader = request.getHeader("Authorization");
        String token = null;

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
        }

        if (token != null) {
            try {
                Claims claims = Jwts.parserBuilder()
                        .setSigningKey(getSignKey())
                        .setAllowedClockSkewSeconds(300) // ADDED: Allow a 5-minute clock skew for validation
                        .build()
                        .parseClaimsJws(token)
                        .getBody();

                String username = claims.getSubject();
                String role = claims.get("role", String.class); // Get role without "ROLE_" prefix

                log.info("AdminModule: Extracted username: {}, role: {}", username, role); // Log for debugging

                if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                    // Prefix the role with "ROLE_" for Spring Security
                    List<GrantedAuthority> authorities = List.of((GrantedAuthority) () -> "ROLE_" + role);
                    User user = new User(username, "", authorities); // Password is not needed for JWT auth

                    UsernamePasswordAuthenticationToken authToken =
                            new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authToken);

                    log.info("AdminModule: User authenticated: {}", username); // Log for debugging
                }
            } catch (Exception e) {
                log.error("AdminModule: Invalid JWT: {}", e.getMessage()); // Use log.error
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid or expired token");
                return;
            }
        }

        filterChain.doFilter(request, response);
    }
}