package com.example.adminmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminmoduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
