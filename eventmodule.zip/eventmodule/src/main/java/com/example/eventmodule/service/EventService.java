package com.example.eventmodule.service;

import com.example.eventmodule.dto.EventRequest;
import com.example.eventmodule.dto.EventResponse;
import com.example.eventmodule.entity.Event;
import com.example.eventmodule.repository.EventRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EventService {

    private final EventRepository eventRepository;

    public void createEvent(EventRequest request, Authentication auth) {
        Event event = Event.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .date(request.getDate())
                .createdBy(auth.getName())
                .build();
        eventRepository.save(event);
    }

    public List<EventResponse> getAllEvents() {
        return eventRepository.findAll().stream()
                .map(e -> EventResponse.builder()
                        .id(e.getId())
                        .title(e.getTitle())
                        .description(e.getDescription())
                        .date(e.getDate())
                        .createdBy(e.getCreatedBy())
                        .build())
                .collect(Collectors.toList());
    }
}
