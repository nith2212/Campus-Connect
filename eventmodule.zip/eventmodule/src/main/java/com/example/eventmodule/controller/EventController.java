package com.example.eventmodule.controller;

import com.example.eventmodule.dto.EventRequest;
import com.example.eventmodule.dto.EventResponse;
import com.example.eventmodule.service.EventService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
public class EventController {

    private final EventService eventService;

    /**
     *Only FACULTY can create events
     * Ensures that only faculty members can access this endpoint.
     */
    @PreAuthorize("hasRole('FACULTY')")
    @PostMapping
    public ResponseEntity<String> createEvent(@RequestBody EventRequest request, Authentication auth) {
        eventService.createEvent(request, auth);
        return ResponseEntity.ok("Event created successfully");
    }

    /**
     * FACULTY, STUDENT, and ADMIN can view events
     * Allows multiple roles to retrieve all events.
     */
    @PreAuthorize("hasAnyRole('FACULTY', 'STUDENT', 'ADMIN')")
    @GetMapping
    public ResponseEntity<List<EventResponse>> getAllEvents() {
        return ResponseEntity.ok(eventService.getAllEvents());
    }
}
