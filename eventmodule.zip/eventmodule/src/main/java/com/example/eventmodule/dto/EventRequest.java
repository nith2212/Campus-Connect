package com.example.eventmodule.dto;


import lombok.Data;
import java.time.LocalDate;

@Data
public class EventRequest {
    private String title;
    private String description;
    private LocalDate date;
}