package com.example.eventmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventmoduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
