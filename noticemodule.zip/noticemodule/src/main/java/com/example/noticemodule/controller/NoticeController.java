package com.example.noticemodule.controller;

import com.example.noticemodule.dto.NoticeRequest;
import com.example.noticemodule.dto.NoticeResponse;
import com.example.noticemodule.service.NoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/notices")
@RequiredArgsConstructor
public class NoticeController {

    private final NoticeService noticeService;

    /**
     * ✅ Only FACULTY can post notices
     */
    @PreAuthorize("hasAuthority('ROLE_FACULTY')")
    @PostMapping
    public ResponseEntity<String> postNotice(@RequestBody NoticeRequest request, Authentication auth) {
        noticeService.postNotice(request, auth);
        return ResponseEntity.ok("Notice posted successfully");
    }

    /**
     * ✅ FACULTY, STUDENT, and ADMIN can view notices
     */
    @PreAuthorize("hasAnyAuthority('ROLE_FACULTY', 'ROLE_STUDENT', 'ROLE_ADMIN')")
    @GetMapping
    public ResponseEntity<List<NoticeResponse>> getNotices(
            @RequestParam(required = false) String department,
            @RequestParam(required = false) String year) {
        return ResponseEntity.ok(noticeService.getNotices(department, year));
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    // Removed Delete and Update endpoints:
    // @DeleteMapping("/notices/{id}")
    // @PreAuthorize("hasRole('ADMIN') || hasAuthority('ROLE_FACULTY')")
    // public ResponseEntity<Void> deleteNotice(@PathVariable Long id) {
    //     noticeService.deleteNotice(id);
    //     return ResponseEntity.noContent().build();
    // }

    // @PutMapping("/notices/{id}")
    // @PreAuthorize("hasRole('ADMIN') || hasAuthority('ROLE_FACULTY')")
    // public ResponseEntity<Void> updateNotice(@PathVariable Long id, @RequestBody NoticeRequest request) {
    //     noticeService.updateNotice(id, request);
    //     return ResponseEntity.noContent().build();
    // }
}