package com.example.noticemodule.repository;

import com.example.noticemodule.entity.Notice;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NoticeRepository extends JpaRepository<Notice, Long> {
    List<Notice> findByDepartmentAndYear(String department, String year);
    List<Notice> findByDepartment(String department);
    List<Notice> findByYear(String year);
}