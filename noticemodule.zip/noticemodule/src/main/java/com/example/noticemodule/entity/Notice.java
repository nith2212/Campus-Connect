package com.example.noticemodule.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import org.hibernate.annotations.CreationTimestamp; // <-- NEW IMPORT

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Notice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String content;
    private String department;
    private String year;
    private String postedBy; // faculty email or name

    @CreationTimestamp // <-- ADD THIS ANNOTATION
    @Column(nullable = false, updatable = false) // Ensures it's not null and not updated after creation
    private LocalDateTime postedOn;
}