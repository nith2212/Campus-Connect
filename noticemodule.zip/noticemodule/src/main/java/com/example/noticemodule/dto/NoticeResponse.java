package com.example.noticemodule.dto;

import lombok.Builder;
import lombok.Data;
// import java.time.LocalDateTime; // Removed as postedOn is removed from DTO

@Data
@Builder
public class NoticeResponse {
    private Long id;
    private String title;
    private String content;
    private String department;
    private String year;
    private String postedBy;
}