package com.example.noticemodule.service;

import com.example.noticemodule.dto.NoticeRequest;
import com.example.noticemodule.dto.NoticeResponse;
import com.example.noticemodule.entity.Notice;
import com.example.noticemodule.repository.NoticeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class NoticeService {

    private final NoticeRepository noticeRepository;

    public void postNotice(NoticeRequest request, Authentication auth) {
        Notice notice = Notice.builder()
                .title(request.getTitle())
                .content(request.getContent())
                .department(request.getDepartment())
                .year(request.getYear())
                .postedBy(auth.getName())
                .build();
        noticeRepository.save(notice);
    }

    public List<NoticeResponse> getNotices(String department, String year) {
        List<Notice> notices;

        if (department != null && year != null) {
            notices = noticeRepository.findByDepartmentAndYear(department, year);
        } else if (department != null) {
            notices = noticeRepository.findByDepartment(department);
        } else if (year != null) {
            notices = noticeRepository.findByYear(year);
        } else {
            notices = noticeRepository.findAll();
        }

        return notices.stream()
                .map(n -> NoticeResponse.builder()
                        .id(n.getId())
                        .title(n.getTitle())
                        .content(n.getContent())
                        .department(n.getDepartment())
                        .year(n.getYear())
                        .postedBy(n.getPostedBy())
                        // .postedOn(n.getPostedOn()) // Removed mapping
                        .build())
                .collect(Collectors.toList());
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // Removed deleteNotice method
    // public void deleteNotice(Long id) {
    //     noticeRepository.deleteById(id);
    // }

    // Removed updateNotice method
    // public void updateNotice(Long id, NoticeRequest request) {
    //     Notice existingNotice = noticeRepository.findById(id)
    //             .orElseThrow(() -> new RuntimeException("Notice not found"));

    //     existingNotice.setTitle(request.getTitle());
    //     existingNotice.setContent(request.getContent());
    //     existingNotice.setDepartment(request.getDepartment());
    //     existingNotice.setYear(request.getYear());
    //     // Do NOT update postedOn here, as it's the creation timestamp
    //     noticeRepository.save(existingNotice);
    // }
}