package com.example.resourcemodule.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ResourceResponse {
    private Long id;
    private String title;
    private String fileUrl;
    private String subject;
    private String uploadedBy;
}
