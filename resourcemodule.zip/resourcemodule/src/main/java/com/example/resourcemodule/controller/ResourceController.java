package com.example.resourcemodule.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.example.resourcemodule.dto.ResourceRequest;
import com.example.resourcemodule.dto.ResourceResponse;
import com.example.resourcemodule.service.ResourceService;

import java.util.List;

@RestController
@RequestMapping("/api/resources")
@RequiredArgsConstructor
public class ResourceController {

    private final ResourceService resourceService;

    /**
     * ✅ Only FACULTY can upload resources
     * - Role extracted from JWT must be prefixed with "ROLE_"
     */
    @PreAuthorize("hasAuthority('ROLE_FACULTY')")
    @PostMapping
    public ResponseEntity<String> upload(@RequestBody ResourceRequest request, Authentication auth) {
        // --- ADDED LOGGING HERE ---
        System.out.println("ResourceController - Received upload request:");
        System.out.println("  Title: '" + request.getTitle() + "'");
        System.out.println("  FileURL: '" + request.getFileUrl() + "'"); // This is the key line to observe
        System.out.println("  Subject: '" + request.getSubject() + "'");
        System.out.println("  Authenticated user: '" + auth.getName() + "'");
        // --- END LOGGING ---

        resourceService.uploadResource(request, auth);
        return ResponseEntity.ok("Resource uploaded successfully");
    }

    /**
     * ✅ FACULTY, STUDENT, and ADMIN can view resources
     */
    @PreAuthorize("hasAnyAuthority('ROLE_FACULTY', 'ROLE_STUDENT', 'ROLE_ADMIN')")
    @GetMapping
    public ResponseEntity<List<ResourceResponse>> getBySubject(@RequestParam String subject) {
        return ResponseEntity.ok(resourceService.getResourcesBySubject(subject));
    }
    
    /**
     * ✅ Only FACULTY can delete resources
     * - Role extracted from JWT must be prefixed with "ROLE_"
     */
    @PreAuthorize("hasAuthority('ROLE_FACULTY')")
    @DeleteMapping("/{resourceId}")
    public ResponseEntity<String> delete(@PathVariable Long resourceId, Authentication auth) {
        // --- ADDED LOGGING HERE ---
        System.out.println("ResourceController - Received delete request:");
        System.out.println("  Resource ID: '" + resourceId + "'");
        System.out.println("  Authenticated user: '" + auth.getName() + "'");
        // --- END LOGGING ---

        resourceService.deleteResource(resourceId, auth);
        return ResponseEntity.ok("Resource deleted successfully");
    }

    
    
    
    
    
}