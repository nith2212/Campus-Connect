package com.example.resourcemodule.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.example.resourcemodule.dto.ResourceRequest;
import com.example.resourcemodule.dto.ResourceResponse;
import com.example.resourcemodule.entity.Resource;
import com.example.resourcemodule.repository.ResourceRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ResourceService {

    private final ResourceRepository resourceRepository;

    public void uploadResource(ResourceRequest request, Authentication auth) {
        Resource resource = Resource.builder()
                .title(request.getTitle())
                .fileUrl(request.getFileUrl())
                .subject(request.getSubject())
                .uploadedBy(auth.getName())
                .build();
        resourceRepository.save(resource);
    }

    public List<ResourceResponse> getResourcesBySubject(String subject) {
        return resourceRepository.findBySubject(subject).stream()
                .map(r -> ResourceResponse.builder()
                        .id(r.getId())
                        .title(r.getTitle())
                        .fileUrl(r.getFileUrl())
                        .subject(r.getSubject())
                        .uploadedBy(r.getUploadedBy())
                        .build())
                .collect(Collectors.toList());
    }

    public void deleteResource(Long resourceId, Authentication auth) {
        Resource resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new RuntimeException("Resource not found"));

        // Ensure only the uploader can delete the resource
        if (!resource.getUploadedBy().equals(auth.getName())) {
            throw new RuntimeException("You are not authorized to delete this resource");
        }

        resourceRepository.deleteById(resourceId);
    }
}
