package com.example.resourcemodule.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.resourcemodule.entity.Resource;

import java.util.List;

public interface ResourceRepository extends JpaRepository<Resource, Long> {
    List<Resource> findBySubject(String subject);
}