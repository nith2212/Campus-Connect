package com.example.resourcemodule.dto;

import lombok.Data;

@Data
public class ResourceRequest {
    private String title;
    private String fileUrl;
    private String subject;
}
